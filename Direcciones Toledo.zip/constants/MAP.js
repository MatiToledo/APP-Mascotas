export default {
  API_KEY: "AIzaSyCFvt1spTbsQZf0rUbkPyl12AoouLK7iDo",
};
