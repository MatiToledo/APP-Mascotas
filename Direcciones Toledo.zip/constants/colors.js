export default {
  primary: "#3ec487",
  secondary: "#ffe08a",
};
