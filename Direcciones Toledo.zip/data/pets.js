export const PETS = [
  {
    petId: 1,
    petName: "Nina",
    petDescription: "Caniche Toy",
    petPhoto:
      "https://aperrados.com/wp-content/uploads/2009/02/origenes-del-caniche-toy-800x600.jpg",
    petUbication: "Plaza Colon",
  },
  {
    petId: 2,
    petName: "Almendra",
    petDescription: "Gata naranja",
    petPhoto:
      "https://luisaolvera.com/wp-content/uploads/2019/06/todo-lo-que-necesitas-saber-sobre-el-gato-naranja-655x368.jpg",
    petUbication: "Plaza de la musica",
  },
];
