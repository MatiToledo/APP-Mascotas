export const AUTH = { userName: "", token: "", email: "" };
